<Dialog>
  <DialogTrigger>Open Dialog</DialogTrigger>
  <DialogContent>
    <DialogHeader>
      <DialogTitle>Dialog Title</DialogTitle>
      <DialogDescription>
        This is a description of what this dialog does.
      </DialogDescription>
    </DialogHeader>
    {/* Rest of the dialog content */}
  </DialogContent>
</Dialog>

